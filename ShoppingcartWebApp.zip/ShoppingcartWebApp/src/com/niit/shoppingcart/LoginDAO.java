package com.niit.shoppingcart;

public class LoginDAO 
{
	 public boolean isValidUser(String userid,String password)
	 
	 {
		if(userid.equals(password))
		  {
			 
		  }
		  else
		  {
			 
		  }
	 }

}
