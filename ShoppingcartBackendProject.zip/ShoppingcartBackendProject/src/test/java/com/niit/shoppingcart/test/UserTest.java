package com.niit.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {

	public static void main(String[] args) 
	{

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		User user = (User) context.getBean("user");
		
		user.setId("US120");
		user.setName("USName");
		user.setPassword("123");
		user.setMobile("1234");
		user.setMail("Mail");
		user.setAddress("Chennai");
		
		userDAO.saveOrUpdate(user);
		
		
	}

}
