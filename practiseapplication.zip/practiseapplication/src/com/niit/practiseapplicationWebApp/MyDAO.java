package com.niit.practiseapplicationWebApp;

public class MyDAO 
{
	 public boolean isValidUser(String userid , String password)
	 {
		if(userid.equals(password)) 
		{
			 return true;
		}
		else
		{
			 return false;
			 
		}
	 }

}
