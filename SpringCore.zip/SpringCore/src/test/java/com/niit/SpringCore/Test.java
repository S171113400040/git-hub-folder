package com.niit.SpringCore;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) 
	{
	 AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	 
	 context.scan("com.niit.SpringCore");
	 context.refresh();
	 
	 context.getBean("category");
	 context.getBean("product");
	 Product p= (Product)  context.getBean("product");
	 p.setId("123");
	System.out.println(p.getId());
	}

}
